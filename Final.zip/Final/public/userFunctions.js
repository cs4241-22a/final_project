const createUser = function(e){
    // prevent default form action from being carried out
    e.preventDefault()

    const username = document.querySelector( '#username' ),
          password = document.querySelector( '#password' ),
          json = { username: username.value,
                   password: password.value },
          body = JSON.stringify( json )

    if(username.value == "" || password.value == ""){
      alert("Neither Email nor Password can be empty!");
      document.getElementById("VotingForm").reset();

      return false;
    }

    fetch( '/create-user', {
      method:'POST',
      body 
    }).then( function( response ) {
      window.location = "/";
    })

    return false
  }